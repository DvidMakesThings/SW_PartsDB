# DMTDB KiCad Libraries

Extract this ZIP to a location of your choice, then configure KiCad:

## KiCad Path Variables

In KiCad, go to Preferences → Configure Paths and add:

| Name            | Path                                    |
|-----------------|-----------------------------------------|
| DMTDB_SYM       | /path/to/extracted/symbols/             |
| DMTDB_FOOTPRINT | /path/to/extracted/footprints/          |
| DMTDB_3D        | /path/to/extracted/3dmodels/            |

Replace "/path/to/extracted/" with the actual path where you extracted this ZIP.

## Add Libraries

### Footprint Library
1. Preferences → Manage Footprint Libraries → Global Libraries
2. Click Add (+)
3. Nickname: DMTDB
4. Library Path: ${DMTDB_FOOTPRINT}

### Symbol Library (HTTP)
The HTTP library provides real-time symbol browsing from the DMTDB server.
See the main DMTDB README for HTTP library setup.

## Sync Updates

To get the latest library files, download a fresh copy from:
  http://YOUR_SERVER:5000 → "Download Libraries" button

Or run the sync manually by re-downloading and extracting.
