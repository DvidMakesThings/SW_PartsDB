# DMTDB - DMT Parts Database

Complete Python-only parts database web application with template-driven field management and KiCad integration.

## Features

- **DMT Numbering System**: Auto-generation of DMTUID with TT/FF/CC/SS/XXX structure
- **Template-Driven**: Field validation based on `dmt_templates.json` (TT+FF key)
- **CSV Import**: Bulk import with detailed error reporting (row# + reason)
- **Web UI**: Browse, search, add, edit, delete parts
- **Search Optimized**: Fast barcode scanner support with Enter-key detection
- **Datasheet Management**: URL or local file support with path traversal protection
- **REST API**: KiCad-ready endpoints for integration
- **SQLite/PostgreSQL**: Portable schema design

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the Application

```bash
python main.py
```

The application will:
- Initialize the SQLite database (`dmtdb.sqlite`)
- Start the web server on http://localhost:5000

### 3. Access the Application

- **Web UI**: http://localhost:5000
- **API Docs**: http://localhost:5000/api-docs
- **Health Check**: http://localhost:5000/api/health

## Project Structure

```
project/
├── main.py              # Flask application entry point
├── models.py            # SQLAlchemy Part model
├── database.py          # Database initialization
├── api.py               # REST API endpoints
├── csv_importer.py      # CSV import with validation
├── requirements.txt     # Python dependencies
├── dmt_schema.json      # Numbering schema (provided)
├── dmt_templates.json   # Template definitions (provided)
├── DMT_Partslib.csv     # Sample parts data (provided)
├── templates/           # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── part_detail.html
│   ├── part_form.html
│   └── import.html
├── static/              # CSS and JavaScript
│   ├── style.css
│   └── script.js
└── datasheets/          # Local datasheet files (created automatically)
```

## Usage

### Adding Parts

#### Via Web UI
1. Navigate to "Add Part"
2. Provide either:
   - Complete DMTUID: `DMT-TTFFCCSSXXX`
   - OR TT/FF/CC/SS (system auto-generates XXX)
3. Fill in part details
4. Submit

#### Via CSV Import
1. Navigate to "Import CSV"
2. Upload CSV file with headers
3. System will:
   - Validate/generate DMTUIDs
   - Filter fields per template
   - Report errors with row numbers
4. Review import results

### Searching Parts

- **Web UI**: Type in search bar and press Enter
- **Barcode Scanner**: Scan DMTUID, press Enter
  - Exact match → Opens part details
  - No match → Shows search results
- **API**: Use `/api/parts?search=...` endpoint

### Managing Datasheets

**Option 1: External URL**
```
https://www.example.com/datasheet.pdf
```

**Option 2: Local File**
1. Place file in `./datasheets/` directory
2. Enter filename in Datasheet field: `datasheet.pdf`
3. System serves with path traversal protection

## CSV Import Rules

### DMTUID Generation
1. **If DMTUID exists and valid**: Use it as-is
2. **Else if TT/FF/CC/SS exist**: Generate XXX = max(XXX in group) + 1
3. **Else**: Reject row with error

### Template-Based Filtering
- Template key = TT + FF (4 digits)
- Only fields in template are stored in `extra_json`
- Common fields (MPN, Manufacturer, etc.) always stored
- Extra columns ignored if not in template
- No template? Store all non-empty fields in `extra_json`

### CSV Format Requirements
- UTF-8 encoding
- Header row required
- Either DMTUID OR (TT + FF + CC + SS) per row

## REST API

### Endpoints

**List/Search Parts**
```
GET /api/parts
  ?search=keyword
  &tt=01&ff=02&cc=01&ss=01
  &mpn=CRCW
  &manufacturer=Vishay
  &value=10K
  &limit=100&offset=0
```

**Get Part by DMTUID**
```
GET /api/parts/{dmtuid}
```

**Create Part**
```
POST /api/parts
Content-Type: application/json

{
  "DMTUID": "DMT-01020101001",
  "TT": "01", "FF": "02", "CC": "01", "SS": "01", "XXX": "001",
  "MPN": "...",
  "Manufacturer": "...",
  ...
}
```

**Update Part**
```
PUT /api/parts/{dmtuid}
Content-Type: application/json

{
  "Quantity": 50,
  "Location": "Shelf A"
}
```

**Delete Part**
```
DELETE /api/parts/{dmtuid}
```

**List In-Stock Parts (KiCad)**
```
GET /api/parts/in-stock
  ?search=10K
  &limit=100
```

### Response Format

```json
{
  "total": 150,
  "limit": 100,
  "offset": 0,
  "parts": [
    {
      "DMTUID": "DMT-01020101001",
      "TT": "01",
      "FF": "02",
      "CC": "01",
      "SS": "01",
      "XXX": "001",
      "MPN": "CRCW040210K0FKED",
      "Manufacturer": "Vishay Dale",
      "Location": "RLC-Box",
      "Quantity": 100,
      "Value": "10K 1% 1/16W",
      "Description": "Chip Resistor",
      "RoHS": "YES",
      "Datasheet": "https://...",
      "KiCadSymbol": null,
      "KiCadFootprint": null,
      "KiCadLibRef": null,
      ...
    }
  ]
}
```

## KiCad Integration

The API is designed for KiCad integration with:

1. **Endpoints**:
   - `/api/parts/in-stock` - Available parts
   - `/api/parts?mpn=...` - Search by MPN
   - `/api/parts?manufacturer=...` - Search by manufacturer

2. **Fields**:
   - `KiCadSymbol` - Symbol library reference
   - `KiCadFootprint` - Footprint reference
   - `KiCadLibRef` - Library reference

3. **Clean Architecture**:
   - Data layer: `models.py`
   - API layer: `api.py`
   - UI layer: `main.py`, `templates/`

## Database Schema

### Part Model

**Universal Fields** (always stored):
- `DMTUID` (PK) - DMT-TTFFCCSSXXX
- `TT`, `FF`, `CC`, `SS`, `XXX` - Numbering components

**Common Fields** (model columns):
- `MPN`, `Manufacturer`, `Location`
- `Quantity`, `Value`, `Description`
- `RoHS`, `Datasheet`
- `KiCadSymbol`, `KiCadFootprint`, `KiCadLibRef`

**Template-Specific Fields**:
- `extra_json` - JSON/JSONB field containing template-allowed fields

### Indexes
- Primary key: `DMTUID`
- Index: `TT`, `FF`, `CC`, `SS` (individual + composite)
- Index: `MPN`, `Manufacturer`, `Value`, `Quantity`

## Configuration

### Environment Variables

```bash
# Database path (default: dmtdb.sqlite)
export DB_PATH=/path/to/database.sqlite

# Flask secret key (default: dev key)
export SECRET_KEY=your-secret-key-here
```

### Database Migration (SQLite → PostgreSQL)

1. Update `database.py`:
```python
DATABASE_URL = 'postgresql://user:pass@localhost/dmtdb'
```

2. Schema is compatible - no code changes needed

## Testing the Import

Import the provided sample data:

```bash
# Run the application
python main.py

# In browser:
# 1. Go to http://localhost:5000/import
# 2. Upload DMT_Partslib.csv
# 3. Review import report
```

Expected results:
- Parts with valid DMTUIDs: imported as-is
- Parts with TT/FF/CC/SS: DMTUID auto-generated
- Parts with conflicts: skipped with warning
- Invalid rows: reported with row# and reason

## Security

- **Path Traversal Protection**: Datasheet serving restricted to `./datasheets/`
- **Input Validation**: All user inputs validated
- **SQL Injection**: Protected via SQLAlchemy ORM
- **File Upload**: CSV only, size limit enforced

## Performance

- **Search**: Indexed fields for fast queries
- **Pagination**: API supports limit/offset
- **Database**: SQLite for dev, PostgreSQL for production
- **Caching**: Browser caching for static assets

## Troubleshooting

**Database locked error**
```bash
# SQLite: Close all connections
rm dmtdb.sqlite
python main.py
```

**Import fails**
- Check CSV encoding (must be UTF-8)
- Verify header row exists
- Ensure TT/FF/CC/SS or DMTUID in each row

**Datasheet not found**
- Verify file in `./datasheets/` directory
- Check filename matches (case-sensitive)
- Test with full URL instead

**Port 5000 in use**
- Edit `main.py`: change `port=5000` to another port

## Development

### Adding New Endpoints

Edit `api.py`:
```python
@api_bp.route('/parts/custom', methods=['GET'])
def custom_endpoint():
    # Your code here
    return jsonify({'result': 'data'})
```

### Modifying Templates

Edit files in `templates/` directory. Uses Jinja2 syntax.

### Styling

Edit `static/style.css` for visual changes.

## License

MIT License - See LICENSE file

## Support

For issues or questions:
1. Check API docs: http://localhost:5000/api-docs
2. Review import error messages (row# + reason)
3. Check database: `sqlite3 dmtdb.sqlite`

---

**DMTDB** - Built with Python, Flask, SQLAlchemy
