"""
REST API endpoints for DMTDB.
KiCad integration ready with clean separation.
"""
from flask import Blueprint, jsonify, request
from sqlalchemy import or_, and_
from models import Part
from database import get_db_session

api_bp = Blueprint('api', __name__, url_prefix='/api')


@api_bp.route('/parts', methods=['GET'])
def list_parts():
    """
    List/search parts with optional filters.
    Query params:
      - search: fuzzy search across MPN, Manufacturer, Value, Description, DMTUID
      - tt, ff, cc, ss: filter by numbering components
      - mpn: filter by MPN
      - manufacturer: filter by Manufacturer
      - value: filter by Value
      - limit: max results (default 100)
      - offset: pagination offset (default 0)
    """
    session = get_db_session()
    try:
        query = session.query(Part)

        # Search filter
        search = request.args.get('search', '').strip()
        if search:
            search_pattern = f"%{search}%"
            query = query.filter(or_(
                Part.DMTUID.like(search_pattern),
                Part.MPN.like(search_pattern),
                Part.Manufacturer.like(search_pattern),
                Part.Value.like(search_pattern),
                Part.Description.like(search_pattern)
            ))

        # Specific filters
        if request.args.get('tt'):
            query = query.filter(Part.TT == request.args['tt'])
        if request.args.get('ff'):
            query = query.filter(Part.FF == request.args['ff'])
        if request.args.get('cc'):
            query = query.filter(Part.CC == request.args['cc'])
        if request.args.get('ss'):
            query = query.filter(Part.SS == request.args['ss'])
        if request.args.get('mpn'):
            query = query.filter(Part.MPN.like(f"%{request.args['mpn']}%"))
        if request.args.get('manufacturer'):
            query = query.filter(Part.Manufacturer.like(f"%{request.args['manufacturer']}%"))
        if request.args.get('value'):
            query = query.filter(Part.Value.like(f"%{request.args['value']}%"))

        # Pagination
        limit = min(int(request.args.get('limit', 100)), 1000)
        offset = int(request.args.get('offset', 0))

        total = query.count()
        parts = query.limit(limit).offset(offset).all()

        return jsonify({
            'total': total,
            'limit': limit,
            'offset': offset,
            'parts': [p.to_dict() for p in parts]
        })
    finally:
        session.close()


@api_bp.route('/parts/<dmtuid>', methods=['GET'])
def get_part(dmtuid):
    """Get a single part by DMTUID."""
    session = get_db_session()
    try:
        part = session.query(Part).filter_by(DMTUID=dmtuid).first()
        if not part:
            return jsonify({'error': 'Part not found'}), 404
        return jsonify(part.to_dict())
    finally:
        session.close()


@api_bp.route('/parts', methods=['POST'])
def create_part():
    """Create a new part."""
    session = get_db_session()
    try:
        data = request.get_json()

        # Validate required fields
        if not all(k in data for k in ['DMTUID', 'TT', 'FF', 'CC', 'SS', 'XXX']):
            return jsonify({'error': 'Missing required fields'}), 400

        # Check if part exists
        if session.query(Part).filter_by(DMTUID=data['DMTUID']).first():
            return jsonify({'error': 'Part already exists'}), 409

        # Create part
        part = Part(**data)
        session.add(part)
        session.commit()

        return jsonify(part.to_dict()), 201
    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        session.close()


@api_bp.route('/parts/<dmtuid>', methods=['PUT'])
def update_part(dmtuid):
    """Update an existing part."""
    session = get_db_session()
    try:
        part = session.query(Part).filter_by(DMTUID=dmtuid).first()
        if not part:
            return jsonify({'error': 'Part not found'}), 404

        data = request.get_json()

        # Update fields
        for key, value in data.items():
            if hasattr(part, key) and key != 'DMTUID':  # Don't allow DMTUID change
                setattr(part, key, value)

        session.commit()
        return jsonify(part.to_dict())
    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        session.close()


@api_bp.route('/parts/<dmtuid>', methods=['DELETE'])
def delete_part(dmtuid):
    """Delete a part."""
    session = get_db_session()
    try:
        part = session.query(Part).filter_by(DMTUID=dmtuid).first()
        if not part:
            return jsonify({'error': 'Part not found'}), 404

        session.delete(part)
        session.commit()
        return jsonify({'message': 'Part deleted'}), 200
    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        session.close()


@api_bp.route('/parts/in-stock', methods=['GET'])
def list_in_stock():
    """
    KiCad integration: List parts with Quantity > 0.
    Query params: same as /parts
    """
    session = get_db_session()
    try:
        query = session.query(Part).filter(Part.Quantity > 0)

        # Apply same filters as list_parts
        search = request.args.get('search', '').strip()
        if search:
            search_pattern = f"%{search}%"
            query = query.filter(or_(
                Part.DMTUID.like(search_pattern),
                Part.MPN.like(search_pattern),
                Part.Manufacturer.like(search_pattern)
            ))

        limit = min(int(request.args.get('limit', 100)), 1000)
        offset = int(request.args.get('offset', 0))

        total = query.count()
        parts = query.limit(limit).offset(offset).all()

        return jsonify({
            'total': total,
            'limit': limit,
            'offset': offset,
            'parts': [p.to_dict() for p in parts]
        })
    finally:
        session.close()


@api_bp.route('/health', methods=['GET'])
def health():
    """Health check endpoint."""
    return jsonify({'status': 'ok', 'service': 'DMTDB'})
