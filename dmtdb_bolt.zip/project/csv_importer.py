"""
CSV import module with DMTUID validation/generation and template-driven field filtering.
"""
import csv
import json
import re
from typing import Dict, List, Tuple, Optional
from models import Part
from sqlalchemy.orm import Session


class ImportResult:
    """Container for import results with detailed reporting."""

    def __init__(self):
        self.success_count = 0
        self.error_count = 0
        self.skipped_count = 0
        self.errors: List[Dict] = []
        self.warnings: List[Dict] = []
        self.imported_parts: List[str] = []

    def add_error(self, row_num: int, dmtuid: str, reason: str):
        self.error_count += 1
        self.errors.append({
            'row': row_num,
            'dmtuid': dmtuid,
            'reason': reason
        })

    def add_warning(self, row_num: int, dmtuid: str, message: str):
        self.warnings.append({
            'row': row_num,
            'dmtuid': dmtuid,
            'message': message
        })

    def add_success(self, dmtuid: str):
        self.success_count += 1
        self.imported_parts.append(dmtuid)

    def get_report(self) -> str:
        """Generate human-readable report."""
        lines = [
            "=" * 60,
            "CSV Import Report",
            "=" * 60,
            f"Successfully imported: {self.success_count} parts",
            f"Errors: {self.error_count}",
            f"Warnings: {len(self.warnings)}",
            ""
        ]

        if self.errors:
            lines.append("ERRORS:")
            for err in self.errors:
                lines.append(f"  Row {err['row']}: {err['dmtuid']} - {err['reason']}")
            lines.append("")

        if self.warnings:
            lines.append("WARNINGS:")
            for warn in self.warnings:
                lines.append(f"  Row {warn['row']}: {warn['dmtuid']} - {warn['message']}")
            lines.append("")

        lines.append("=" * 60)
        return "\n".join(lines)


class CSVImporter:
    """Handles CSV import with DMTUID validation and template-based field filtering."""

    # Universal fields always stored
    UNIVERSAL_FIELDS = {'DMTUID', 'TT', 'FF', 'CC', 'SS', 'XXX'}

    # Common fields that map directly to model columns
    COMMON_FIELDS = {
        'MPN', 'Manufacturer', 'Location', 'Quantity', 'Value',
        'Description', 'RoHS', 'Datasheet', 'KiCadSymbol',
        'KiCadFootprint', 'KiCadLibRef', 'SN'
    }

    def __init__(self, templates_path: str = 'dmt_templates.json'):
        """Initialize importer with templates."""
        self.templates = self._load_templates(templates_path)

    def _load_templates(self, path: str) -> Dict:
        """Load template definitions from JSON file."""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Warning: Could not load templates from {path}: {e}")
            return {}

    def validate_dmtuid(self, dmtuid: str) -> bool:
        """Validate DMTUID format: DMT-TTFFCCSSXXX."""
        if not dmtuid:
            return False
        pattern = r'^DMT-\d{2}\d{2}\d{2}\d{2}\d{3}$'
        return bool(re.match(pattern, dmtuid))

    def parse_dmtuid(self, dmtuid: str) -> Optional[Dict[str, str]]:
        """Parse DMTUID into components."""
        if not self.validate_dmtuid(dmtuid):
            return None
        # DMT-TTFFCCSSXXX
        parts = dmtuid.replace('DMT-', '')
        return {
            'TT': parts[0:2],
            'FF': parts[2:4],
            'CC': parts[4:6],
            'SS': parts[6:8],
            'XXX': parts[8:11]
        }

    def generate_dmtuid(self, tt: str, ff: str, cc: str, ss: str, session: Session) -> str:
        """Generate next available DMTUID for given TT/FF/CC/SS."""
        # Find max XXX for this TTFFCCSS group
        prefix = f"DMT-{tt}{ff}{cc}{ss}"
        parts = session.query(Part).filter(Part.DMTUID.like(f"{prefix}%")).all()

        if not parts:
            xxx = '001'
        else:
            max_xxx = max(int(p.XXX) for p in parts)
            xxx = f"{max_xxx + 1:03d}"
            if int(xxx) > 999:
                raise ValueError(f"XXX overflow for {prefix} (max 999 reached)")

        return f"{prefix}{xxx}"

    def get_template_fields(self, tt: str, ff: str) -> Optional[List[str]]:
        """Get allowed fields for a template key (TT+FF)."""
        key = f"{tt}{ff}"
        return self.templates.get(key)

    def filter_fields(self, row: Dict, tt: str, ff: str) -> Tuple[Dict, Dict]:
        """
        Filter row fields based on template.
        Returns: (common_fields, extra_json)
        """
        template_fields = self.get_template_fields(tt, ff)
        common = {}
        extra = {}

        for key, value in row.items():
            # Skip empty values
            if not value or value.strip() == '':
                continue

            # Universal fields handled separately
            if key in self.UNIVERSAL_FIELDS:
                continue

            # Common fields always stored
            if key in self.COMMON_FIELDS:
                common[key] = value
                continue

            # Template-specific fields
            if template_fields is None:
                # No template: store in extra_json
                extra[key] = value
            elif key in template_fields:
                # Field allowed by template: store in extra_json
                extra[key] = value
            # else: field not in template, ignore

        return common, extra

    def import_csv(self, csv_path: str, session: Session) -> ImportResult:
        """
        Import parts from CSV file.

        Logic:
        1. If DMTUID exists and valid: use it
        2. Else if TT/FF/CC/SS exist: generate DMTUID with next XXX
        3. Else: reject row with error
        """
        result = ImportResult()

        try:
            with open(csv_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)

                for row_num, row in enumerate(reader, start=2):  # Row 2 = first data row
                    try:
                        self._import_row(row, row_num, session, result)
                    except Exception as e:
                        result.add_error(row_num, row.get('DMTUID', 'N/A'), str(e))

                # Commit all successful imports
                session.commit()

        except Exception as e:
            session.rollback()
            result.add_error(0, 'N/A', f"File error: {e}")

        return result

    def _import_row(self, row: Dict, row_num: int, session: Session, result: ImportResult):
        """Import a single row from CSV."""
        # Try to get or generate DMTUID
        dmtuid = row.get('DMTUID', '').strip()
        tt = row.get('TT', '').strip()
        ff = row.get('FF', '').strip()
        cc = row.get('CC', '').strip()
        ss = row.get('SS', '').strip()

        # Case 1: DMTUID exists and is valid
        if dmtuid and self.validate_dmtuid(dmtuid):
            parsed = self.parse_dmtuid(dmtuid)
            tt, ff, cc, ss = parsed['TT'], parsed['FF'], parsed['CC'], parsed['SS']
            xxx = parsed['XXX']

        # Case 2: TT/FF/CC/SS exist, generate DMTUID
        elif tt and ff and cc and ss:
            try:
                dmtuid = self.generate_dmtuid(tt, ff, cc, ss, session)
                xxx = dmtuid[-3:]
            except ValueError as e:
                result.add_error(row_num, f"{tt}{ff}{cc}{ss}", str(e))
                return

        # Case 3: Insufficient data
        else:
            result.add_error(
                row_num,
                dmtuid or f"TT={tt} FF={ff} CC={cc} SS={ss}",
                "Missing DMTUID or TT/FF/CC/SS"
            )
            return

        # Check if part already exists
        existing = session.query(Part).filter_by(DMTUID=dmtuid).first()
        if existing:
            result.add_warning(row_num, dmtuid, "Part already exists, skipping")
            result.skipped_count += 1
            return

        # Filter fields based on template
        common_fields, extra_json = self.filter_fields(row, tt, ff)

        # Create part
        part = Part(
            DMTUID=dmtuid,
            TT=tt,
            FF=ff,
            CC=cc,
            SS=ss,
            XXX=xxx,
            extra_json=extra_json
        )

        # Set common fields
        for field, value in common_fields.items():
            if hasattr(part, field):
                # Handle Quantity as integer
                if field == 'Quantity':
                    try:
                        setattr(part, field, int(value) if value else 0)
                    except ValueError:
                        setattr(part, field, 0)
                else:
                    setattr(part, field, value)

        session.add(part)
        result.add_success(dmtuid)
