"""
DMTDB - DMT Parts Database Web Application
Single command run: python main.py
"""
import os
import re
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, jsonify
from werkzeug.utils import secure_filename
from database import init_db, get_db_session
from models import Part
from csv_importer import CSVImporter
from api import api_bp

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max file size

# Register API blueprint
app.register_blueprint(api_bp)

# Ensure datasheets directory exists
DATASHEETS_DIR = Path('./datasheets')
DATASHEETS_DIR.mkdir(exist_ok=True)


def is_safe_path(path: str) -> bool:
    """Check if path is safe (no directory traversal)."""
    try:
        requested = Path(DATASHEETS_DIR / path).resolve()
        return requested.is_relative_to(DATASHEETS_DIR.resolve())
    except:
        return False


@app.route('/')
def index():
    """Main page with parts listing and search."""
    session = get_db_session()
    try:
        search = request.args.get('search', '').strip()

        if search:
            search_pattern = f"%{search}%"
            parts = session.query(Part).filter(
                (Part.DMTUID.like(search_pattern)) |
                (Part.MPN.like(search_pattern)) |
                (Part.Manufacturer.like(search_pattern)) |
                (Part.Value.like(search_pattern)) |
                (Part.Description.like(search_pattern))
            ).order_by(Part.DMTUID).limit(100).all()
        else:
            parts = session.query(Part).order_by(Part.DMTUID).limit(100).all()

        return render_template('index.html', parts=parts, search=search)
    finally:
        session.close()


@app.route('/part/<dmtuid>')
def part_detail(dmtuid):
    """Part details page."""
    session = get_db_session()
    try:
        part = session.query(Part).filter_by(DMTUID=dmtuid).first()
        if not part:
            flash('Part not found', 'error')
            return redirect(url_for('index'))
        return render_template('part_detail.html', part=part)
    finally:
        session.close()


@app.route('/part/add', methods=['GET', 'POST'])
def add_part():
    """Add new part form."""
    if request.method == 'POST':
        session = get_db_session()
        try:
            # Get form data
            dmtuid = request.form.get('DMTUID', '').strip()
            tt = request.form.get('TT', '').strip()
            ff = request.form.get('FF', '').strip()
            cc = request.form.get('CC', '').strip()
            ss = request.form.get('SS', '').strip()
            xxx = request.form.get('XXX', '').strip()

            # Generate DMTUID if not provided but TT/FF/CC/SS are
            if not dmtuid and tt and ff and cc and ss:
                importer = CSVImporter()
                try:
                    dmtuid = importer.generate_dmtuid(tt, ff, cc, ss, session)
                    xxx = dmtuid[-3:]
                except ValueError as e:
                    flash(f'Error generating DMTUID: {e}', 'error')
                    return redirect(url_for('add_part'))

            if not dmtuid:
                flash('DMTUID or TT/FF/CC/SS required', 'error')
                return redirect(url_for('add_part'))

            # Check if exists
            if session.query(Part).filter_by(DMTUID=dmtuid).first():
                flash('Part already exists', 'error')
                return redirect(url_for('part_detail', dmtuid=dmtuid))

            # Create part
            part = Part(
                DMTUID=dmtuid,
                TT=tt or dmtuid[4:6],
                FF=ff or dmtuid[6:8],
                CC=cc or dmtuid[8:10],
                SS=ss or dmtuid[10:12],
                XXX=xxx or dmtuid[12:15],
                MPN=request.form.get('MPN', '').strip(),
                Manufacturer=request.form.get('Manufacturer', '').strip(),
                Location=request.form.get('Location', '').strip(),
                Quantity=int(request.form.get('Quantity', 0) or 0),
                Value=request.form.get('Value', '').strip(),
                Description=request.form.get('Description', '').strip(),
                RoHS=request.form.get('RoHS', '').strip(),
                Datasheet=request.form.get('Datasheet', '').strip(),
            )

            session.add(part)
            session.commit()
            flash('Part added successfully', 'success')
            return redirect(url_for('part_detail', dmtuid=dmtuid))
        except Exception as e:
            session.rollback()
            flash(f'Error adding part: {e}', 'error')
            return redirect(url_for('add_part'))
        finally:
            session.close()

    return render_template('part_form.html', part=None, action='Add')


@app.route('/part/<dmtuid>/edit', methods=['GET', 'POST'])
def edit_part(dmtuid):
    """Edit existing part."""
    session = get_db_session()
    try:
        part = session.query(Part).filter_by(DMTUID=dmtuid).first()
        if not part:
            flash('Part not found', 'error')
            return redirect(url_for('index'))

        if request.method == 'POST':
            try:
                # Update fields
                part.MPN = request.form.get('MPN', '').strip()
                part.Manufacturer = request.form.get('Manufacturer', '').strip()
                part.Location = request.form.get('Location', '').strip()
                part.Quantity = int(request.form.get('Quantity', 0) or 0)
                part.Value = request.form.get('Value', '').strip()
                part.Description = request.form.get('Description', '').strip()
                part.RoHS = request.form.get('RoHS', '').strip()
                part.Datasheet = request.form.get('Datasheet', '').strip()

                session.commit()
                flash('Part updated successfully', 'success')
                return redirect(url_for('part_detail', dmtuid=dmtuid))
            except Exception as e:
                session.rollback()
                flash(f'Error updating part: {e}', 'error')

        return render_template('part_form.html', part=part, action='Edit')
    finally:
        session.close()


@app.route('/part/<dmtuid>/delete', methods=['POST'])
def delete_part(dmtuid):
    """Delete a part."""
    session = get_db_session()
    try:
        part = session.query(Part).filter_by(DMTUID=dmtuid).first()
        if part:
            session.delete(part)
            session.commit()
            flash('Part deleted successfully', 'success')
        else:
            flash('Part not found', 'error')
    except Exception as e:
        session.rollback()
        flash(f'Error deleting part: {e}', 'error')
    finally:
        session.close()
    return redirect(url_for('index'))


@app.route('/import', methods=['GET', 'POST'])
def import_csv():
    """CSV import page."""
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file uploaded', 'error')
            return redirect(url_for('import_csv'))

        file = request.files['file']
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(url_for('import_csv'))

        if not file.filename.endswith('.csv'):
            flash('File must be a CSV', 'error')
            return redirect(url_for('import_csv'))

        try:
            # Save temporary file
            filename = secure_filename(file.filename)
            temp_path = f'/tmp/{filename}'
            file.save(temp_path)

            # Import
            session = get_db_session()
            try:
                importer = CSVImporter()
                result = importer.import_csv(temp_path, session)

                # Clean up temp file
                os.remove(temp_path)

                # Show results
                flash(f'Import complete: {result.success_count} parts imported, {result.error_count} errors',
                      'success' if result.error_count == 0 else 'warning')

                return render_template('import.html', result=result)
            finally:
                session.close()
        except Exception as e:
            flash(f'Import error: {e}', 'error')
            return redirect(url_for('import_csv'))

    return render_template('import.html', result=None)


@app.route('/datasheets/<path:filename>')
def serve_datasheet(filename):
    """Serve datasheet files with path traversal protection."""
    if not is_safe_path(filename):
        return "Invalid path", 403

    try:
        return send_from_directory(DATASHEETS_DIR, filename)
    except FileNotFoundError:
        return "File not found", 404


@app.route('/api-docs')
def api_docs():
    """API documentation page."""
    docs = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>DMTDB API Documentation</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 900px; margin: 40px auto; padding: 20px; }
            h1 { color: #333; }
            h2 { color: #666; margin-top: 30px; }
            code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; }
            pre { background: #f4f4f4; padding: 15px; border-radius: 5px; overflow-x: auto; }
            .endpoint { background: #e8f4f8; padding: 15px; margin: 15px 0; border-radius: 5px; }
            .method { display: inline-block; padding: 3px 8px; border-radius: 3px; font-weight: bold; }
            .get { background: #61affe; color: white; }
            .post { background: #49cc90; color: white; }
            .put { background: #fca130; color: white; }
            .delete { background: #f93e3e; color: white; }
        </style>
    </head>
    <body>
        <h1>DMTDB REST API Documentation</h1>
        <p>Base URL: <code>/api</code></p>

        <h2>Endpoints</h2>

        <div class="endpoint">
            <span class="method get">GET</span> <code>/api/parts</code>
            <p>List/search parts with optional filters</p>
            <p><strong>Query Parameters:</strong></p>
            <ul>
                <li><code>search</code> - Fuzzy search across DMTUID, MPN, Manufacturer, Value, Description</li>
                <li><code>tt, ff, cc, ss</code> - Filter by numbering components</li>
                <li><code>mpn</code> - Filter by MPN</li>
                <li><code>manufacturer</code> - Filter by Manufacturer</li>
                <li><code>value</code> - Filter by Value</li>
                <li><code>limit</code> - Max results (default 100, max 1000)</li>
                <li><code>offset</code> - Pagination offset (default 0)</li>
            </ul>
        </div>

        <div class="endpoint">
            <span class="method get">GET</span> <code>/api/parts/{dmtuid}</code>
            <p>Get a single part by DMTUID</p>
        </div>

        <div class="endpoint">
            <span class="method post">POST</span> <code>/api/parts</code>
            <p>Create a new part</p>
            <p><strong>Request Body:</strong> JSON object with part fields (DMTUID, TT, FF, CC, SS, XXX required)</p>
        </div>

        <div class="endpoint">
            <span class="method put">PUT</span> <code>/api/parts/{dmtuid}</code>
            <p>Update an existing part</p>
            <p><strong>Request Body:</strong> JSON object with fields to update</p>
        </div>

        <div class="endpoint">
            <span class="method delete">DELETE</span> <code>/api/parts/{dmtuid}</code>
            <p>Delete a part</p>
        </div>

        <div class="endpoint">
            <span class="method get">GET</span> <code>/api/parts/in-stock</code>
            <p>List parts with Quantity > 0 (KiCad integration)</p>
            <p><strong>Query Parameters:</strong> Same as <code>/api/parts</code></p>
        </div>

        <div class="endpoint">
            <span class="method get">GET</span> <code>/api/health</code>
            <p>Health check endpoint</p>
        </div>

        <h2>KiCad Integration</h2>
        <p>The API provides endpoints specifically designed for KiCad integration:</p>
        <ul>
            <li><code>GET /api/parts/in-stock</code> - List available parts for BOM</li>
            <li>Filter by MPN, Manufacturer, Value for component matching</li>
            <li>Parts include KiCadSymbol, KiCadFootprint, KiCadLibRef fields</li>
        </ul>

        <h2>Response Format</h2>
        <p>All endpoints return JSON. Part objects include:</p>
        <pre>{
  "DMTUID": "DMT-01020101001",
  "TT": "01", "FF": "02", "CC": "01", "SS": "01", "XXX": "001",
  "MPN": "CRCW040210K0FKED",
  "Manufacturer": "Vishay Dale",
  "Location": "RLC-Box",
  "Quantity": 100,
  "Value": "10K 1% 1/16W",
  "Description": "Chip Resistor",
  "RoHS": "YES",
  "Datasheet": "https://...",
  "KiCadSymbol": null,
  "KiCadFootprint": null,
  "KiCadLibRef": null,
  ... (template-specific fields in extra_json)
}</pre>
    </body>
    </html>
    """
    return docs


if __name__ == '__main__':
    # Initialize database
    print("Initializing DMTDB...")
    init_db()

    # Run Flask development server
    print("Starting DMTDB web server...")
    print("Access the application at: http://localhost:5000")
    print("API documentation: http://localhost:5000/api-docs")
    app.run(host='0.0.0.0', port=5000, debug=True)
