"""
SQLAlchemy models for DMTDB parts database.
Designed to be portable between SQLite and PostgreSQL.
"""
from sqlalchemy import Column, String, Integer, Text, JSON, Index
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class Part(Base):
    """
    Part model with universal fields and template-specific data in extra_json.

    Universal fields: DMTUID, TT, FF, CC, SS, XXX
    Common fields: MPN, Manufacturer, Location, Quantity, Value, Description, RoHS, Datasheet
    KiCad fields: KiCadSymbol, KiCadFootprint, KiCadLibRef
    Template-specific fields: stored in extra_json as dict
    """
    __tablename__ = 'parts'

    # Primary key and numbering
    DMTUID = Column(String(16), primary_key=True)  # DMT-TTFFCCSSXXX
    TT = Column(String(2), nullable=False, index=True)
    FF = Column(String(2), nullable=False, index=True)
    CC = Column(String(2), nullable=False, index=True)
    SS = Column(String(2), nullable=False, index=True)
    XXX = Column(String(3), nullable=False)

    # Common fields
    MPN = Column(String(255), index=True)
    Manufacturer = Column(String(255), index=True)
    Location = Column(String(255))
    Quantity = Column(Integer, default=0)
    Value = Column(String(255), index=True)
    Description = Column(Text)
    RoHS = Column(String(10))
    Datasheet = Column(Text)

    # KiCad integration fields
    KiCadSymbol = Column(String(255))
    KiCadFootprint = Column(String(255))
    KiCadLibRef = Column(String(255))

    # Template-specific fields stored as JSON
    # For SQLite: JSON type works as TEXT with JSON validation
    # For PostgreSQL: will use JSONB for better performance
    extra_json = Column(JSON, default=dict)

    # Indexes for common queries
    __table_args__ = (
        Index('idx_ttffccss', 'TT', 'FF', 'CC', 'SS'),
        Index('idx_quantity', 'Quantity'),
    )

    def to_dict(self):
        """Convert part to dictionary including extra_json fields."""
        result = {
            'DMTUID': self.DMTUID,
            'TT': self.TT,
            'FF': self.FF,
            'CC': self.CC,
            'SS': self.SS,
            'XXX': self.XXX,
            'MPN': self.MPN,
            'Manufacturer': self.Manufacturer,
            'Location': self.Location,
            'Quantity': self.Quantity,
            'Value': self.Value,
            'Description': self.Description,
            'RoHS': self.RoHS,
            'Datasheet': self.Datasheet,
            'KiCadSymbol': self.KiCadSymbol,
            'KiCadFootprint': self.KiCadFootprint,
            'KiCadLibRef': self.KiCadLibRef,
        }
        # Merge extra_json fields
        if self.extra_json:
            result.update(self.extra_json)
        return result
