// DMTDB Client-side JavaScript
// Optimized for barcode scanner input

document.addEventListener('DOMContentLoaded', function() {
    // Enhanced search with Enter key handling
    const searchInput = document.getElementById('searchInput');
    const searchForm = document.getElementById('searchForm');

    if (searchInput && searchForm) {
        // Handle Enter key for barcode scanners
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchValue = searchInput.value.trim();

            if (!searchValue) {
                window.location.href = '/';
                return;
            }

            // Check if it's an exact DMTUID match
            const dmtuidPattern = /^DMT-\d{11}$/;
            if (dmtuidPattern.test(searchValue)) {
                // Exact DMTUID: check if exists and redirect to details
                checkPartExists(searchValue);
            } else {
                // Regular search: submit form
                searchForm.submit();
            }
        });

        // Auto-focus search on page load (except on mobile)
        if (window.innerWidth > 768) {
            searchInput.focus();
        }
    }

    // Form validation for part add/edit
    const partForm = document.querySelector('.part-form');
    if (partForm) {
        partForm.addEventListener('submit', function(e) {
            const dmtuid = document.getElementById('DMTUID');
            const tt = document.getElementById('TT');
            const ff = document.getElementById('FF');
            const cc = document.getElementById('CC');
            const ss = document.getElementById('SS');

            // Check if either DMTUID or TT/FF/CC/SS is provided
            if (dmtuid && !dmtuid.disabled) {
                const hasDmtuid = dmtuid.value.trim() !== '';
                const hasTTFFCCSS = tt.value && ff.value && cc.value && ss.value;

                if (!hasDmtuid && !hasTTFFCCSS) {
                    e.preventDefault();
                    alert('Please provide either a complete DMTUID or TT/FF/CC/SS fields.');
                    return false;
                }

                // Validate DMTUID format if provided
                if (hasDmtuid && !/^DMT-\d{11}$/.test(dmtuid.value)) {
                    e.preventDefault();
                    alert('Invalid DMTUID format. Must be: DMT-TTFFCCSSXXX');
                    return false;
                }

                // Validate TT/FF/CC/SS if provided
                if (hasTTFFCCSS) {
                    if (!/^\d{2}$/.test(tt.value) || !/^\d{2}$/.test(ff.value) ||
                        !/^\d{2}$/.test(cc.value) || !/^\d{2}$/.test(ss.value)) {
                        e.preventDefault();
                        alert('TT/FF/CC/SS must be 2-digit numbers.');
                        return false;
                    }
                }
            }
        });
    }

    // File upload preview
    const fileInput = document.getElementById('file');
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                if (!file.name.endsWith('.csv')) {
                    alert('Please select a CSV file.');
                    this.value = '';
                }
            }
        });
    }
});

// Check if part exists (for exact DMTUID search)
function checkPartExists(dmtuid) {
    fetch(`/api/parts/${dmtuid}`)
        .then(response => {
            if (response.ok) {
                // Part exists: redirect to details
                window.location.href = `/part/${dmtuid}`;
            } else {
                // Part not found: do regular search
                window.location.href = `/?search=${encodeURIComponent(dmtuid)}`;
            }
        })
        .catch(error => {
            console.error('Error checking part:', error);
            // Fallback to regular search
            window.location.href = `/?search=${encodeURIComponent(dmtuid)}`;
        });
}

// Utility: Format DMTUID input (auto-add dashes)
function formatDMTUID(input) {
    let value = input.value.replace(/[^0-9]/g, '');
    if (value.length > 11) {
        value = value.substring(0, 11);
    }
    if (value.length >= 2) {
        input.value = 'DMT-' + value;
    }
}
