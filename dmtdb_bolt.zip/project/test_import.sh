#!/bin/bash
# Quick test script for DMTDB

echo "======================================"
echo "DMTDB Import Test"
echo "======================================"
echo ""

# Check if Python is available
if command -v python3 &> /dev/null; then
    PYTHON=python3
elif command -v python &> /dev/null; then
    PYTHON=python
else
    echo "❌ Python not found. Please install Python 3.8 or higher."
    exit 1
fi

echo "Using: $PYTHON"
echo ""

# Test database initialization
echo "1. Initializing database..."
$PYTHON << 'PYEOF'
from database import init_db
init_db()
print("✓ Database initialized")
PYEOF

if [ $? -ne 0 ]; then
    echo "❌ Database initialization failed"
    echo "   Run: pip install -r requirements.txt"
    exit 1
fi

# Test CSV import
echo ""
echo "2. Importing DMT_Partslib.csv..."
$PYTHON << 'PYEOF'
from database import get_db_session
from csv_importer import CSVImporter

session = get_db_session()
try:
    importer = CSVImporter()
    result = importer.import_csv('DMT_Partslib.csv', session)
    print("")
    print("=" * 60)
    print(f"✓ Import complete!")
    print(f"  Imported: {result.success_count} parts")
    print(f"  Errors: {result.error_count}")
    print(f"  Warnings: {len(result.warnings)}")
    print("=" * 60)
    
    if result.error_count > 0:
        print("\nFirst 5 errors:")
        for err in result.errors[:5]:
            print(f"  Row {err['row']}: {err['reason']}")
finally:
    session.close()
PYEOF

if [ $? -ne 0 ]; then
    echo "❌ Import failed"
    exit 1
fi

# Show sample data
echo ""
echo "3. Verifying data..."
$PYTHON << 'PYEOF'
from database import get_db_session
from models import Part

session = get_db_session()
try:
    total = session.query(Part).count()
    in_stock = session.query(Part).filter(Part.Quantity > 0).count()
    
    print(f"✓ Total parts: {total}")
    print(f"✓ In stock: {in_stock}")
    
    print("\nSample parts:")
    parts = session.query(Part).limit(3).all()
    for p in parts:
        print(f"  {p.DMTUID}: {p.MPN or 'N/A'} ({p.Manufacturer or 'N/A'})")
finally:
    session.close()
PYEOF

echo ""
echo "======================================"
echo "✓ Test complete!"
echo "======================================"
echo ""
echo "To start the web server:"
echo "  $PYTHON main.py"
echo ""
echo "Then open: http://localhost:5000"
echo "======================================"
