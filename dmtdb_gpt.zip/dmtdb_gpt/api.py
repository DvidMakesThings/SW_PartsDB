from __future__ import annotations

from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request, current_app, url_for
from sqlalchemy import and_, or_, select, func, cast, Integer
from sqlalchemy.orm import Session

from models import Part, PartField


api_bp = Blueprint("api", __name__, url_prefix="/api/v1")


SEARCH_KEYS = ["MPN", "Manufacturer", "Value", "Description", "Location"]
LIST_KEYS = ["MPN", "Manufacturer", "Value", "Quantity", "Location", "Description", "Datasheet", "KiCadSymbol", "KiCadFootprint", "KiCadLibRef"]


def _get_session() -> Session:
    return current_app.config["DB_SESSION_FACTORY"]()


def _datasheet_link(ds_value: Optional[str]) -> Optional[Dict[str, str]]:
    if not ds_value:
        return None
    s = ds_value.strip()
    if not s:
        return None
    if s.lower().startswith("http://") or s.lower().startswith("https://"):
        return {"kind": "url", "url": s}

    from pathlib import Path as _Path
    from werkzeug.utils import safe_join as _safe_join

    base = _Path(current_app.root_path) / "datasheets"
    safe = _safe_join(str(base), s)
    if not safe:
        return None
    p = _Path(safe)
    try:
        p.resolve().relative_to(base.resolve())
    except Exception:
        return None
    if not p.exists() or not p.is_file():
        return None

    return {"kind": "local", "url": url_for("ui.serve_datasheet", filename=s)}


def _hydrate_fields(session: Session, dmtuids: List[str], keys: List[str]) -> Dict[str, Dict[str, str]]:
    if not dmtuids:
        return {}
    rows = session.execute(
        select(PartField.part_dmtuid, PartField.key, PartField.value).where(
            PartField.part_dmtuid.in_(dmtuids),
            PartField.key.in_(keys),
        )
    ).all()
    out: Dict[str, Dict[str, str]] = {uid: {} for uid in dmtuids}
    for uid, k, v in rows:
        out.setdefault(uid, {})[k] = v
    return out


def _part_to_dict(part: Part, fields: Dict[str, str]) -> dict:
    ds = fields.get("Datasheet")
    ds_link = _datasheet_link(ds) if ds else None
    return {
        "DMTUID": part.dmtuid,
        "TT": part.tt,
        "FF": part.ff,
        "CC": part.cc,
        "SS": part.ss,
        "XXX": part.xxx,
        "notes": part.notes,
        "extra_json": part.extra_json,
        "fields": fields,
        "datasheet": ds_link,
    }


@api_bp.get("/openapi.json")
def openapi() -> Any:
    spec = {
        "openapi": "3.0.0",
        "info": {"title": "DMTDB API", "version": "1.0.0"},
        "paths": {
            "/api/v1/parts": {"get": {"summary": "List/search parts", "parameters": [
                {"name": "q", "in": "query", "schema": {"type": "string"}},
                {"name": "limit", "in": "query", "schema": {"type": "integer", "default": 50}},
                {"name": "offset", "in": "query", "schema": {"type": "integer", "default": 0}},
            ]}},
            "/api/v1/parts/{dmtuid}": {"get": {"summary": "Get part by DMTUID", "parameters": [
                {"name": "dmtuid", "in": "path", "required": True, "schema": {"type": "string"}},
            ]}},
            "/api/v1/parts/in_stock": {"get": {"summary": "List in-stock parts (Quantity > 0)"}},
            "/api/v1/parts/query": {"get": {"summary": "Query by MPN/Manufacturer/Value", "parameters": [
                {"name": "mpn", "in": "query", "schema": {"type": "string"}},
                {"name": "manufacturer", "in": "query", "schema": {"type": "string"}},
                {"name": "value", "in": "query", "schema": {"type": "string"}},
            ]}},
            "/api/v1/parts/resolve": {"get": {"summary": "Resolve scanner Enter behavior (exact DMTUID else top match)", "parameters": [
                {"name": "q", "in": "query", "schema": {"type": "string"}},
            ]}},
        },
    }
    return jsonify(spec)


@api_bp.get("/parts")
def list_parts() -> Any:
    q = (request.args.get("q") or "").strip()
    limit = int(request.args.get("limit") or 50)
    offset = int(request.args.get("offset") or 0)
    limit = max(1, min(limit, 200))
    offset = max(0, offset)

    session = _get_session()
    try:
        stmt = select(Part)
        if q:
            pattern = f"%{q}%"
            stmt = (
                stmt.outerjoin(PartField, PartField.part_dmtuid == Part.dmtuid)
                .where(
                    or_(
                        Part.dmtuid.ilike(pattern),
                        and_(PartField.key.in_(SEARCH_KEYS), PartField.value.ilike(pattern)),
                    )
                )
                .distinct()
            )
        stmt = stmt.order_by(Part.dmtuid.asc()).offset(offset).limit(limit)

        parts = session.execute(stmt).scalars().all()
        ids = [p.dmtuid for p in parts]
        fields_map = _hydrate_fields(session, ids, LIST_KEYS)

        items = []
        for p in parts:
            f = fields_map.get(p.dmtuid, {})
            ds_link = _datasheet_link(f.get("Datasheet")) if f.get("Datasheet") else None
            items.append({
                "DMTUID": p.dmtuid,
                "TT": p.tt, "FF": p.ff, "CC": p.cc, "SS": p.ss, "XXX": p.xxx,
                "MPN": f.get("MPN", ""),
                "Manufacturer": f.get("Manufacturer", ""),
                "Value": f.get("Value", ""),
                "Quantity": f.get("Quantity", ""),
                "Location": f.get("Location", ""),
                "Description": f.get("Description", ""),
                "datasheet": ds_link,
            })
        return jsonify({"items": items, "count": len(items)})
    finally:
        session.close()


@api_bp.get("/parts/resolve")
def resolve_part() -> Any:
    q = (request.args.get("q") or "").strip()
    if not q:
        return jsonify({"dmtuid": None})

    session = _get_session()
    try:
        exact = session.get(Part, q)
        if exact:
            return jsonify({"dmtuid": exact.dmtuid})

        # case-insensitive exact
        exact2 = session.execute(select(Part).where(func.lower(Part.dmtuid) == q.lower())).scalar_one_or_none()
        if exact2:
            return jsonify({"dmtuid": exact2.dmtuid})

        # fallback to top match
        pattern = f"%{q}%"
        stmt = (
            select(Part)
            .outerjoin(PartField, PartField.part_dmtuid == Part.dmtuid)
            .where(
                or_(
                    Part.dmtuid.ilike(pattern),
                    and_(PartField.key.in_(SEARCH_KEYS), PartField.value.ilike(pattern)),
                )
            )
            .distinct()
            .order_by(Part.dmtuid.asc())
            .limit(1)
        )
        top = session.execute(stmt).scalar_one_or_none()
        return jsonify({"dmtuid": top.dmtuid if top else None})
    finally:
        session.close()


@api_bp.get("/parts/in_stock")
def in_stock() -> Any:
    limit = int(request.args.get("limit") or 200)
    limit = max(1, min(limit, 500))

    session = _get_session()
    try:
        qty_pf = PartField.__table__.alias("qty_pf")
        stmt = (
            select(Part)
            .join(qty_pf, and_(qty_pf.c.part_dmtuid == Part.dmtuid, qty_pf.c.key == "Quantity"))
            .where(cast(qty_pf.c.value, Integer) > 0)
            .order_by(Part.dmtuid.asc())
            .limit(limit)
        )
        parts = session.execute(stmt).scalars().all()
        ids = [p.dmtuid for p in parts]
        fields_map = _hydrate_fields(session, ids, LIST_KEYS)

        items = []
        for p in parts:
            f = fields_map.get(p.dmtuid, {})
            items.append({
                "DMTUID": p.dmtuid,
                "MPN": f.get("MPN", ""),
                "Manufacturer": f.get("Manufacturer", ""),
                "Value": f.get("Value", ""),
                "Quantity": f.get("Quantity", ""),
                "Location": f.get("Location", ""),
                "Description": f.get("Description", ""),
            })
        return jsonify({"items": items, "count": len(items)})
    finally:
        session.close()


@api_bp.get("/parts/query")
def query_parts() -> Any:
    mpn = (request.args.get("mpn") or "").strip()
    manufacturer = (request.args.get("manufacturer") or "").strip()
    value = (request.args.get("value") or "").strip()
    limit = int(request.args.get("limit") or 200)
    limit = max(1, min(limit, 500))

    filters = []
    if mpn:
        filters.append(and_(PartField.key == "MPN", PartField.value.ilike(f"%{mpn}%")))
    if manufacturer:
        filters.append(and_(PartField.key == "Manufacturer", PartField.value.ilike(f"%{manufacturer}%")))
    if value:
        filters.append(and_(PartField.key == "Value", PartField.value.ilike(f"%{value}%")))

    session = _get_session()
    try:
        if not filters:
            return jsonify({"items": [], "count": 0})

        # AND across different keys: intersect sets by grouping
        stmt = (
            select(Part)
            .join(PartField, PartField.part_dmtuid == Part.dmtuid)
            .where(or_(*filters))
            .group_by(Part.dmtuid)
            .having(func.count(func.distinct(PartField.key)) >= len(filters))
            .order_by(Part.dmtuid.asc())
            .limit(limit)
        )
        parts = session.execute(stmt).scalars().all()
        ids = [p.dmtuid for p in parts]
        fields_map = _hydrate_fields(session, ids, LIST_KEYS)

        items = []
        for p in parts:
            f = fields_map.get(p.dmtuid, {})
            items.append({
                "DMTUID": p.dmtuid,
                "MPN": f.get("MPN", ""),
                "Manufacturer": f.get("Manufacturer", ""),
                "Value": f.get("Value", ""),
                "Quantity": f.get("Quantity", ""),
                "Location": f.get("Location", ""),
                "Description": f.get("Description", ""),
            })
        return jsonify({"items": items, "count": len(items)})
    finally:
        session.close()


@api_bp.get("/parts/<path:dmtuid>")
def get_part(dmtuid: str) -> Any:
    session = _get_session()
    try:
        part = session.get(Part, dmtuid)
        if not part:
            return jsonify({"error": "not_found"}), 404
        fields = {pf.key: pf.value for pf in part.fields}
        return jsonify(_part_to_dict(part, fields))
    finally:
        session.close()
