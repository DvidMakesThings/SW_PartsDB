from __future__ import annotations

import csv
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from models import Part, PartField
from schema_loader import SchemaRuntime


UNIVERSAL_COLS = {"DMTUID", "TT", "FF", "CC", "SS", "XXX"}


@dataclass
class ImportErrorRow:
    row: int
    reason: str


@dataclass
class ImportReport:
    inserted: int = 0
    updated: int = 0
    skipped: int = 0
    errors: List[ImportErrorRow] = None

    def to_dict(self) -> dict:
        return {
            "inserted": self.inserted,
            "updated": self.updated,
            "skipped": self.skipped,
            "errors": [e.__dict__ for e in (self.errors or [])],
        }


def _clean_row(row: Dict[str, Any]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for k, v in row.items():
        if k is None:
            continue
        kk = str(k).strip()
        vv = "" if v is None else str(v).strip()
        out[kk] = vv
    return out


def _get_db_max_xxx(session: Session, tt: str, ff: str, cc: str, ss: str) -> int:
    stmt = select(func.max(Part.xxx)).where(
        Part.tt == tt,
        Part.ff == ff,
        Part.cc == cc,
        Part.ss == ss,
    )
    max_xxx = session.execute(stmt).scalar_one_or_none()
    if not max_xxx:
        return 0
    try:
        return int(max_xxx)
    except ValueError:
        return 0


def _upsert_field(session: Session, dmtuid: str, key: str, value: str) -> None:
    existing = session.execute(
        select(PartField).where(PartField.part_dmtuid == dmtuid, PartField.key == key)
    ).scalar_one_or_none()
    if existing:
        existing.value = value
    else:
        session.add(PartField(part_dmtuid=dmtuid, key=key, value=value))


def import_csv(csv_path: str, session: Session, schema_rt: SchemaRuntime) -> ImportReport:
    report = ImportReport(inserted=0, updated=0, skipped=0, errors=[])

    max_cache: Dict[Tuple[str, str, str, str], int] = {}

    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row_idx, raw in enumerate(reader, start=2):
            row = _clean_row(raw)

            dmtuid_in = row.get("DMTUID", "").strip()
            tt_in = row.get("TT", "").strip()
            ff_in = row.get("FF", "").strip()
            cc_in = row.get("CC", "").strip()
            ss_in = row.get("SS", "").strip()

            parsed = schema_rt.parse_dmtuid(dmtuid_in) if dmtuid_in else None

            tt: Optional[str] = None
            ff: Optional[str] = None
            cc: Optional[str] = None
            ss: Optional[str] = None
            xxx: Optional[str] = None
            dmtuid: Optional[str] = None

            if parsed:
                tt, ff, cc, ss, xxx = parsed
                if not schema_rt.is_valid_ttff(tt, ff):
                    parsed = None  # treat as invalid DMTUID
                else:
                    dmtuid = schema_rt.build_dmtuid(tt, ff, cc, ss, xxx)

            if not parsed:
                try:
                    tt = schema_rt.norm_code(tt_in, 2)
                    ff = schema_rt.norm_code(ff_in, 2)
                    cc = schema_rt.norm_code(cc_in, 2)
                    ss = schema_rt.norm_code(ss_in, 2)
                except ValueError:
                    report.skipped += 1
                    report.errors.append(ImportErrorRow(row=row_idx, reason="Missing or invalid TT/FF/CC/SS and DMTUID invalid or absent"))
                    continue

                if not schema_rt.is_valid_ttff(tt, ff):
                    report.skipped += 1
                    report.errors.append(ImportErrorRow(row=row_idx, reason=f"Invalid TTFF for schema: {tt}{ff}"))
                    continue

                group_key = (tt, ff, cc, ss)
                if group_key not in max_cache:
                    max_cache[group_key] = _get_db_max_xxx(session, tt, ff, cc, ss)
                next_xxx = max_cache[group_key] + 1
                if next_xxx > 999:
                    report.skipped += 1
                    report.errors.append(ImportErrorRow(row=row_idx, reason=f"XXX overflow for group {tt}{ff}{cc}{ss}"))
                    continue
                max_cache[group_key] = next_xxx
                xxx = f"{next_xxx:03d}"
                dmtuid = schema_rt.build_dmtuid(tt, ff, cc, ss, xxx)

            assert dmtuid and tt and ff and cc and ss and xxx

            template_fields = schema_rt.template_fields(tt, ff)
            has_template = template_fields is not None

            allowed = set(template_fields or [])

            notes_value = row.get("Notes", "").strip()
            if (not has_template) or ("Notes" in allowed):
                notes_to_store = notes_value if notes_value else None
            else:
                notes_to_store = None

            extra_json: Optional[Dict[str, str]] = None
            if not has_template:
                extra_json = {}
                for k, v in row.items():
                    if k in UNIVERSAL_COLS:
                        continue
                    if k == "Notes":
                        continue
                    if not v:
                        continue
                    extra_json[k] = v
                if not extra_json:
                    extra_json = None

            fields_to_store: Dict[str, str] = {}
            if has_template:
                for k, v in row.items():
                    if k in UNIVERSAL_COLS:
                        continue
                    if k == "Notes":
                        continue
                    if not v:
                        continue
                    if k in allowed:
                        fields_to_store[k] = v

            part = session.get(Part, dmtuid)
            if not part:
                part = Part(dmtuid=dmtuid, tt=tt, ff=ff, cc=cc, ss=ss, xxx=xxx)
                session.add(part)
                is_new = True
            else:
                is_new = False
                part.tt = tt
                part.ff = ff
                part.cc = cc
                part.ss = ss
                part.xxx = xxx

            if notes_to_store is not None:
                part.notes = notes_to_store
            if extra_json is not None:
                part.extra_json = extra_json

            for k, v in fields_to_store.items():
                _upsert_field(session, dmtuid, k, v)

            if is_new:
                report.inserted += 1
            else:
                report.updated += 1

    session.commit()
    return report
