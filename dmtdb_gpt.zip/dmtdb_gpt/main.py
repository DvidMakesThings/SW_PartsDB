from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, render_template
from sqlalchemy import create_engine, select
from sqlalchemy.orm import scoped_session, sessionmaker

from api import api_bp
from csv_import import import_csv
from models import Base, Part
from schema_loader import SchemaRuntime
from ui import ui_bp


def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates")
    app.secret_key = os.environ.get("DMTDB_SECRET_KEY", "dev-secret-key")

    db_path = os.environ.get("DMTDB_SQLITE_PATH", "dmtdb.sqlite3")
    db_url = os.environ.get("DMTDB_DB_URL", f"sqlite:///{db_path}")

    connect_args = {}
    if db_url.startswith("sqlite:///"):
        connect_args = {"check_same_thread": False}

    engine = create_engine(db_url, future=True, connect_args=connect_args)
    SessionFactory = scoped_session(sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True))

    Base.metadata.create_all(engine)

    schema_rt = SchemaRuntime(schema_path="dmt_schema.json", templates_path="dmt_templates.json")

    app.config["DB_ENGINE"] = engine
    app.config["DB_SESSION_FACTORY"] = SessionFactory
    app.config["SCHEMA_RT"] = schema_rt

    app.register_blueprint(api_bp)
    app.register_blueprint(ui_bp)

    @app.errorhandler(404)
    def not_found(_e):
        return render_template("error.html", title="Not found", message="Not found"), 404

    @app.errorhandler(500)
    def server_error(_e):
        return render_template("error.html", title="Server error", message="Server error"), 500

    # Initial CSV import if DB empty
    csv_path = Path("DMT_Partslib.csv")
    if csv_path.exists():
        s = SessionFactory()
        try:
            has_any = s.execute(select(Part.dmtuid).limit(1)).first() is not None
            if not has_any:
                report = import_csv(str(csv_path), s, schema_rt)
                print("Initial import:", report.to_dict())
        finally:
            s.close()

    return app


if __name__ == "__main__":
    app = create_app()
    host = os.environ.get("DMTDB_HOST", "127.0.0.1")
    port = int(os.environ.get("DMTDB_PORT", "5000"))
    debug = os.environ.get("DMTDB_DEBUG", "1") == "1"
    app.run(host=host, port=port, debug=debug)
