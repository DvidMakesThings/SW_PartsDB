from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.types import JSON


class Base(DeclarativeBase):
    pass


class Part(Base):
    __tablename__ = "parts"

    dmtuid: Mapped[str] = mapped_column(String(32), primary_key=True)
    tt: Mapped[str] = mapped_column(String(2), nullable=False, index=True)
    ff: Mapped[str] = mapped_column(String(2), nullable=False, index=True)
    cc: Mapped[str] = mapped_column(String(2), nullable=False, index=True)
    ss: Mapped[str] = mapped_column(String(2), nullable=False, index=True)
    xxx: Mapped[str] = mapped_column(String(3), nullable=False, index=True)

    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    extra_json: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    fields: Mapped[list["PartField"]] = relationship(
        back_populates="part",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    __table_args__ = (
        UniqueConstraint("tt", "ff", "cc", "ss", "xxx", name="uq_part_codes"),
        Index("ix_parts_ttffccss", "tt", "ff", "cc", "ss"),
    )


class PartField(Base):
    __tablename__ = "part_fields"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    part_dmtuid: Mapped[str] = mapped_column(String(32), ForeignKey("parts.dmtuid", ondelete="CASCADE"), nullable=False, index=True)

    key: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)

    part: Mapped[Part] = relationship(back_populates="fields")

    __table_args__ = (
        UniqueConstraint("part_dmtuid", "key", name="uq_partfield_part_key"),
        Index("ix_part_fields_key_value", "key", "value"),
    )
