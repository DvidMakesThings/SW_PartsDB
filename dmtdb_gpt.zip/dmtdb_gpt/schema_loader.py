from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple


DMTUID_RE = re.compile(r"^DMT-(\d{2})(\d{2})(\d{2})(\d{2})(\d{3})$")


def _read_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


@dataclass(frozen=True)
class DomainFamily:
    tt: str
    tt_name: str
    ff: str
    ff_name: str


class SchemaRuntime:
    def __init__(self, schema_path: str = "dmt_schema.json", templates_path: str = "dmt_templates.json") -> None:
        self.schema_path = Path(schema_path)
        self.templates_path = Path(templates_path)

        self.schema = _read_json(self.schema_path)
        self.templates: Dict[str, List[str]] = _read_json(self.templates_path)

        self.domains: List[dict] = self.schema.get("domains", [])
        self.domain_families: List[DomainFamily] = []
        self.allowed_tt: set[str] = set()
        self.allowed_ttff: set[str] = set()
        self.family_map: Dict[str, Dict[str, str]] = {}  # tt -> ff -> ff_name
        self.tt_name: Dict[str, str] = {}

        for d in self.domains:
            tt = str(d.get("tt", "")).zfill(2)
            tt_n = str(d.get("name", "")).strip()
            self.allowed_tt.add(tt)
            self.tt_name[tt] = tt_n
            self.family_map.setdefault(tt, {})
            for f in d.get("families", []):
                ff = str(f.get("ff", "")).zfill(2)
                ff_n = str(f.get("name", "")).strip()
                self.allowed_ttff.add(tt + ff)
                self.family_map[tt][ff] = ff_n
                self.domain_families.append(DomainFamily(tt=tt, tt_name=tt_n, ff=ff, ff_name=ff_n))

        # CC/SS guidelines keyed like "0101_Capacitors"
        self.cc_ss_guidelines: Dict[str, dict] = {}
        for k, v in (self.schema.get("family_cc_ss_guidelines") or {}).items():
            k = str(k)
            m = re.match(r"^(\d{4})_", k)
            if not m:
                continue
            self.cc_ss_guidelines[m.group(1)] = v or {}

    def get_domain_options(self) -> List[Tuple[str, str]]:
        return sorted([(tt, self.tt_name.get(tt, tt)) for tt in self.allowed_tt], key=lambda x: x[0])

    def get_family_options(self, tt: str) -> List[Tuple[str, str]]:
        tt = self.norm_code(tt, 2)
        fam = self.family_map.get(tt, {})
        return sorted([(ff, fam.get(ff, ff)) for ff in fam.keys()], key=lambda x: x[0])

    def get_cc_ss_options(self, ttff: str) -> Tuple[List[Tuple[str, str]], List[Tuple[str, str]]]:
        ttff = self.norm_code(ttff, 4)
        g = self.cc_ss_guidelines.get(ttff) or {}
        cc = g.get("cc") or {}
        ss = g.get("ss") or {}
        cc_opts = sorted([(k, str(v)) for k, v in cc.items()], key=lambda x: x[0])
        ss_opts = sorted([(k, str(v)) for k, v in ss.items()], key=lambda x: x[0])
        return cc_opts, ss_opts

    def is_valid_ttff(self, tt: str, ff: str) -> bool:
        try:
            tt = self.norm_code(tt, 2)
            ff = self.norm_code(ff, 2)
        except ValueError:
            return False
        return (tt + ff) in self.allowed_ttff

    @staticmethod
    def norm_code(val: str, length: int) -> str:
        s = "" if val is None else str(val).strip()
        if s == "":
            raise ValueError("missing code")
        if not s.isdigit():
            raise ValueError("code must be digits")
        s = s.zfill(length)
        if len(s) != length:
            raise ValueError("invalid code length")
        return s

    @staticmethod
    def build_dmtuid(tt: str, ff: str, cc: str, ss: str, xxx: str) -> str:
        tt = SchemaRuntime.norm_code(tt, 2)
        ff = SchemaRuntime.norm_code(ff, 2)
        cc = SchemaRuntime.norm_code(cc, 2)
        ss = SchemaRuntime.norm_code(ss, 2)
        xxx = SchemaRuntime.norm_code(xxx, 3)
        return f"DMT-{tt}{ff}{cc}{ss}{xxx}"

    @staticmethod
    def parse_dmtuid(dmtuid: str) -> Optional[Tuple[str, str, str, str, str]]:
        if not dmtuid:
            return None
        m = DMTUID_RE.match(str(dmtuid).strip())
        if not m:
            return None
        return m.group(1), m.group(2), m.group(3), m.group(4), m.group(5)

    def template_fields(self, tt: str, ff: str) -> Optional[List[str]]:
        try:
            key = self.norm_code(tt, 2) + self.norm_code(ff, 2)
        except ValueError:
            return None
        return self.templates.get(key)

    def template_key_from_ttff(self, ttff: str) -> str:
        ttff = self.norm_code(ttff, 4)
        return ttff
