from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from flask import Blueprint, abort, current_app, flash, redirect, render_template, request, send_file, url_for
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from werkzeug.utils import secure_filename, safe_join

from csv_import import import_csv
from models import Part, PartField
from schema_loader import SchemaRuntime


ui_bp = Blueprint("ui", __name__)


LIST_KEYS = ["MPN", "Manufacturer", "Value", "Quantity", "Location", "Description", "Datasheet", "KiCadSymbol", "KiCadFootprint", "KiCadLibRef"]


def _get_session() -> Session:
    return current_app.config["DB_SESSION_FACTORY"]()


def _schema_rt() -> SchemaRuntime:
    return current_app.config["SCHEMA_RT"]


def _hydrate_fields(session: Session, dmtuids: List[str], keys: List[str]) -> Dict[str, Dict[str, str]]:
    if not dmtuids:
        return {}
    rows = session.execute(
        select(PartField.part_dmtuid, PartField.key, PartField.value).where(
            PartField.part_dmtuid.in_(dmtuids),
            PartField.key.in_(keys),
        )
    ).all()
    out: Dict[str, Dict[str, str]] = {uid: {} for uid in dmtuids}
    for uid, k, v in rows:
        out.setdefault(uid, {})[k] = v
    return out


def _template_fields(tt: str, ff: str) -> Tuple[Optional[List[str]], Optional[str]]:
    rt = _schema_rt()
    fields = rt.template_fields(tt, ff)
    key = None
    if fields is not None:
        key = rt.norm_code(tt, 2) + rt.norm_code(ff, 2)
    return fields, key


def _allowed_set(fields: Optional[List[str]]) -> set[str]:
    return set(fields or [])


def _datasheet_is_url(s: str) -> bool:
    sl = s.lower()
    return sl.startswith("http://") or sl.startswith("https://")


def _datasheet_display(ds_value: Optional[str]) -> Optional[Dict[str, str]]:
    if not ds_value:
        return None
    s = ds_value.strip()
    if not s:
        return None
    if _datasheet_is_url(s):
        return {"kind": "url", "url": s}

    base = Path(current_app.root_path) / "datasheets"
    safe = safe_join(str(base), s)
    if not safe:
        return None
    p = Path(safe)
    try:
        p.resolve().relative_to(base.resolve())
    except Exception:
        return None
    if not p.exists() or not p.is_file():
        return None

    return {"kind": "local", "url": url_for("ui.serve_datasheet", filename=s)}


@ui_bp.get("/")
def index() -> Any:
    # initial load: first 50 parts
    session = _get_session()
    try:
        parts = session.execute(select(Part).order_by(Part.dmtuid.asc()).limit(50)).scalars().all()
        ids = [p.dmtuid for p in parts]
        fields_map = _hydrate_fields(session, ids, LIST_KEYS)
        items = []
        for p in parts:
            f = fields_map.get(p.dmtuid, {})
            items.append({
                "DMTUID": p.dmtuid,
                "MPN": f.get("MPN", ""),
                "Manufacturer": f.get("Manufacturer", ""),
                "Value": f.get("Value", ""),
                "Quantity": f.get("Quantity", ""),
                "Location": f.get("Location", ""),
                "Description": f.get("Description", ""),
                "datasheet": _datasheet_display(f.get("Datasheet")) if f.get("Datasheet") else None,
            })
        return render_template("index.html", items=items)
    finally:
        session.close()


@ui_bp.get("/parts/<path:dmtuid>")
def detail(dmtuid: str) -> Any:
    session = _get_session()
    try:
        part = session.get(Part, dmtuid)
        if not part:
            abort(404)
        fields = {pf.key: pf.value for pf in part.fields}
        ds = fields.get("Datasheet")
        ds_link = _datasheet_display(ds) if ds else None
        return render_template(
            "detail.html",
            part=part,
            fields=fields,
            datasheet=ds_link,
        )
    finally:
        session.close()


@ui_bp.get("/parts/new")
def new_part_step() -> Any:
    rt = _schema_rt()
    tt = (request.args.get("tt") or "").strip()
    ff = (request.args.get("ff") or "").strip()
    cc = (request.args.get("cc") or "").strip()
    ss = (request.args.get("ss") or "").strip()

    domain_opts = rt.get_domain_options()
    family_opts = rt.get_family_options(tt) if tt else []
    ttff = None
    cc_opts = []
    ss_opts = []
    fields = None
    if tt and ff:
        try:
            tt2 = rt.norm_code(tt, 2)
            ff2 = rt.norm_code(ff, 2)
            if rt.is_valid_ttff(tt2, ff2):
                ttff = tt2 + ff2
                cc_opts, ss_opts = rt.get_cc_ss_options(ttff)
                fields, _ = _template_fields(tt2, ff2)
        except ValueError:
            pass

    return render_template(
        "add_edit.html",
        mode="new",
        domain_opts=domain_opts,
        family_opts=family_opts,
        cc_opts=cc_opts,
        ss_opts=ss_opts,
        tt=tt,
        ff=ff,
        cc=cc,
        ss=ss,
        template_fields=fields,
        part=None,
        current_values={},
    )


def _next_xxx(session: Session, tt: str, ff: str, cc: str, ss: str) -> str:
    stmt = select(func.max(Part.xxx)).where(Part.tt == tt, Part.ff == ff, Part.cc == cc, Part.ss == ss)
    max_xxx = session.execute(stmt).scalar_one_or_none()
    mx = int(max_xxx) if max_xxx and str(max_xxx).isdigit() else 0
    nx = mx + 1
    if nx > 999:
        raise ValueError("XXX overflow")
    return f"{nx:03d}"


@ui_bp.post("/parts/new")
def create_part() -> Any:
    rt = _schema_rt()
    form = request.form

    try:
        tt = rt.norm_code(form.get("TT", ""), 2)
        ff = rt.norm_code(form.get("FF", ""), 2)
        cc = rt.norm_code(form.get("CC", ""), 2)
        ss = rt.norm_code(form.get("SS", ""), 2)
    except ValueError:
        flash("Invalid TT/FF/CC/SS", "error")
        return redirect(url_for("ui.new_part_step"))

    if not rt.is_valid_ttff(tt, ff):
        flash(f"Invalid TTFF for schema: {tt}{ff}", "error")
        return redirect(url_for("ui.new_part_step", tt=tt, ff=ff, cc=cc, ss=ss))

    template_fields = rt.template_fields(tt, ff)
    allowed = _allowed_set(template_fields)

    session = _get_session()
    try:
        xxx = _next_xxx(session, tt, ff, cc, ss)
        dmtuid = rt.build_dmtuid(tt, ff, cc, ss, xxx)

        part = Part(dmtuid=dmtuid, tt=tt, ff=ff, cc=cc, ss=ss, xxx=xxx)

        # Notes allowed only if template missing or explicitly includes Notes
        notes_in = (form.get("Notes") or "").strip()
        if (template_fields is None) or ("Notes" in allowed):
            part.notes = notes_in if notes_in else None

        extra_json: Optional[Dict[str, str]] = None
        if template_fields is None:
            extra_json = {}
            for k, v in form.items():
                if k in ("TT", "FF", "CC", "SS"):
                    continue
                if k in ("Notes", "extra_json"):
                    continue
                vv = (v or "").strip()
                if vv:
                    extra_json[k] = vv
            part.extra_json = extra_json or None

        session.add(part)

        # Store allowed template fields only
        if template_fields is not None:
            for k in template_fields:
                if k in ("Notes", "extra_json"):
                    continue
                v = (form.get(k) or "").strip()
                if not v:
                    continue
                session.add(PartField(part_dmtuid=dmtuid, key=k, value=v))

        session.commit()
        flash(f"Created {dmtuid}", "ok")
        return redirect(url_for("ui.detail", dmtuid=dmtuid))
    except Exception as e:
        session.rollback()
        flash(str(e), "error")
        return redirect(url_for("ui.new_part_step", tt=tt, ff=ff, cc=cc, ss=ss))
    finally:
        session.close()


@ui_bp.get("/parts/<path:dmtuid>/edit")
def edit_part(dmtuid: str) -> Any:
    rt = _schema_rt()
    session = _get_session()
    try:
        part = session.get(Part, dmtuid)
        if not part:
            abort(404)

        template_fields, _ = _template_fields(part.tt, part.ff)
        current_values = {pf.key: pf.value for pf in part.fields}

        domain_opts = rt.get_domain_options()
        family_opts = rt.get_family_options(part.tt)
        cc_opts, ss_opts = rt.get_cc_ss_options(part.tt + part.ff)

        return render_template(
            "add_edit.html",
            mode="edit",
            domain_opts=domain_opts,
            family_opts=family_opts,
            cc_opts=cc_opts,
            ss_opts=ss_opts,
            tt=part.tt,
            ff=part.ff,
            cc=part.cc,
            ss=part.ss,
            template_fields=template_fields,
            part=part,
            current_values=current_values,
        )
    finally:
        session.close()


@ui_bp.post("/parts/<path:dmtuid>/edit")
def update_part(dmtuid: str) -> Any:
    session = _get_session()
    rt = _schema_rt()
    form = request.form

    try:
        part = session.get(Part, dmtuid)
        if not part:
            abort(404)

        template_fields = rt.template_fields(part.tt, part.ff)
        allowed = _allowed_set(template_fields)

        # Notes allowed only if template missing or explicitly includes Notes
        notes_in = (form.get("Notes") or "").strip()
        if (template_fields is None) or ("Notes" in allowed):
            part.notes = notes_in if notes_in else None

        if template_fields is None:
            extra_json = {}
            for k, v in form.items():
                if k in ("Notes", "extra_json"):
                    continue
                if k in ("TT", "FF", "CC", "SS", "XXX", "DMTUID"):
                    continue
                vv = (v or "").strip()
                if vv:
                    extra_json[k] = vv
            part.extra_json = extra_json or None

        # Upsert template fields
        if template_fields is not None:
            for k in template_fields:
                if k == "Notes":
                    continue
                v = (form.get(k) or "").strip()
                existing = session.execute(
                    select(PartField).where(PartField.part_dmtuid == dmtuid, PartField.key == k)
                ).scalar_one_or_none()
                if not v:
                    if existing:
                        session.delete(existing)
                    continue
                if existing:
                    existing.value = v
                else:
                    session.add(PartField(part_dmtuid=dmtuid, key=k, value=v))

        session.commit()
        flash("Saved", "ok")
        return redirect(url_for("ui.detail", dmtuid=dmtuid))
    except Exception as e:
        session.rollback()
        flash(str(e), "error")
        return redirect(url_for("ui.edit_part", dmtuid=dmtuid))
    finally:
        session.close()


@ui_bp.post("/parts/<path:dmtuid>/delete")
def delete_part(dmtuid: str) -> Any:
    session = _get_session()
    try:
        part = session.get(Part, dmtuid)
        if not part:
            abort(404)
        session.delete(part)
        session.commit()
        flash("Deleted", "ok")
        return redirect(url_for("ui.index"))
    finally:
        session.close()


@ui_bp.get("/import")
def import_page() -> Any:
    return render_template("import.html", report=None)


@ui_bp.post("/import")
def import_upload() -> Any:
    if "file" not in request.files:
        flash("No file", "error")
        return redirect(url_for("ui.import_page"))

    f = request.files["file"]
    if not f.filename:
        flash("No file", "error")
        return redirect(url_for("ui.import_page"))

    filename = secure_filename(f.filename)
    tmp_dir = Path(current_app.instance_path) / "uploads"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp_path = tmp_dir / filename
    f.save(tmp_path)

    session = _get_session()
    try:
        report = import_csv(str(tmp_path), session, _schema_rt())
        return render_template("import.html", report=report.to_dict())
    except Exception as e:
        session.rollback()
        flash(str(e), "error")
        return redirect(url_for("ui.import_page"))
    finally:
        session.close()


@ui_bp.get("/api-docs")
def api_docs() -> Any:
    return render_template("api_docs.html")


@ui_bp.get("/datasheets/<path:filename>")
def serve_datasheet(filename: str) -> Any:
    base = Path(current_app.root_path) / "datasheets"
    safe = safe_join(str(base), filename)
    if not safe:
        abort(404)
    p = Path(safe)
    try:
        p.resolve().relative_to(base.resolve())
    except Exception:
        abort(404)
    if not p.exists() or not p.is_file():
        abort(404)
    return send_file(str(p), as_attachment=False)
